﻿Partial Class newDataSet
    Partial Public Class facturaDataTable
        Private Sub facturaDataTable_facturaRowChanging(sender As Object, e As facturaRowChangeEvent) Handles Me.facturaRowChanging

        End Sub

    End Class
End Class

Namespace newDataSetTableAdapters
    Partial Public Class clienteTableAdapter
    End Class
End Namespace

Namespace newDataSetTableAdapters
    Partial Public Class clienteTableAdapter
    End Class
End Namespace
